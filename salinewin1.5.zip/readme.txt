salinewin.exe by pankoza
This is a Malware
This is very dangerous for the non-safety version
The non-safety version will corrupt the MBR and make the PC unusable. Run it only on a virtual machine
I'm not responsible for any damages
Credits to GetMBR and Malsteve527 for the Hue Function and credits to EthernalVortex for PRGBQUAD

changelog:
1.0 - Initial release
1.5 - bugfix release, replace GetMBR's Hue function with Malsteve527's, change the sine waves payload, and fix bugs in the MBR (hopefully make it work on PCs with InsydeH2O BIOS, and use a newer MBR overwriting code that does not do an unnecessary loop that makes HDDs heat and shortens the lives of SSDs), also use a newer taskmgr disabling code that does not rely on cmd.exe or reg.exe