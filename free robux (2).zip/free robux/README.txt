🖖
Live long and prosper